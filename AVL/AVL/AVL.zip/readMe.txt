This program was created in xcode and runs on an LLVM compiler. To run it, add all 
the files except TestAVL.cpp to a project. The main function is in RotationGame.cpp. 
You can input boards through text files. To see all the different moves done in the 
aStarSolve function (solving with an avl tree) switch seeAll to true (first line of 
the function). To see all the different moves done in the bruteForceSolve function,
uncomment the designated lines in the function. 
